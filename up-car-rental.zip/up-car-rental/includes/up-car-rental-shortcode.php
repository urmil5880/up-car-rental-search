<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;	// Exit if accessed directly
}

function wpcr_get_all_vehicle_types( $atts, $content = null ){
// setup the query
ob_start();
    $car_query = new WP_Query( array(
        'post_type' 		=> WPCR_POST_TYPE,
        'posts_per_page' 	=> -1,
        'post_status'    	=>  'publish',
        'order' 			=> 'ASC',
        'orderby' 			=> 'title',
    ) );?>
    <section class="container">
        <div class="row justify-content-center">
        <?php
        if ( $car_query->have_posts() ) { ?>
         <div class="col-lg-8">
            <?php while ( $car_query->have_posts() ) : $car_query->the_post(); ?>
                <div class="media entry-listing">
                  <?php if (has_post_thumbnail( $car_query->ID ) ): ?>
                  <?php 
                      $attachmentId = get_post_thumbnail_id(get_the_ID());
                      $thumbnail_url = wp_get_attachment_image_src($attachmentId, 'car-image', false );
                      $thumbnail_url = $thumbnail_url[0];
                      ?>
                      <div class="entry-thumb">
                          <img src="<?php echo $thumbnail_url; ?>" class="img-thumbnail" alt="">
                      </div>
                  <?php endif; ?>
                  <div class="media-body pl-4">
                      <h3 class="border-bottom title pb-1"><?php the_title(); ?></h3>
                      <div class="entry-info d-flex flex-column flex-md-row justify-content-between align-items-start align-items-lg-center">
                          <?php $driver_name = get_post_meta( get_the_ID(), '_driver_name', true );
                          $vehicle_number = get_post_meta( get_the_ID(), '_vehicle_number', true ); ?>
                         <p>Vehical Number : <?=$vehicle_number;?></p>
                         <p>Driver name: <?=$driver_name;?></p>
                         
                      </div>
                      <div class="entry-content">
                        <p>Vehicle type: <?php $rsterms = get_the_terms(get_the_ID(), WPVT_CAT);
                          $reseCats = '';
                          foreach ($rsterms as $rsterm) {
                            $reseCats .= '<span class="cardSubtitle">' . esc_html($rsterm->name) . '</span>';
                          }
                          $reseCats = trim($reseCats); //remove extra space from end
                          echo rtrim($reseCats, ','); ?></p>
                         <p>Description: <?=wp_trim_words( get_the_content(), 20, '...' );?></p>
                      </div>
                      <a href="<?php the_permalink(); ?>" class="mt-5 btn btn-view">View Details</a>
                  </div>
              </div>
              <div class="seprater">
                 <img src="<?=SEPRATER_IMG;?>" alt="">
              </div>
            <?php endwhile;
              wp_reset_postdata(); ?>
          </div>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }else{
    	 echo '<div class="col-lg-8">';
    	 echo '<p><strong>No Vehicle Found</strong></p>';
    	 echo '</div>';
    }
  	wp_reset_postdata(); 
  	return ob_get_clean();?>
      </div>
  </section>
<?php
}
// '[up_all_vehicles]' shortcode
add_shortcode('up_all_vehicles','wpcr_get_all_vehicle_types');
?>
