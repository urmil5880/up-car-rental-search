<?php

if ( !defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Initialization function
add_action('init', 'up_cpt_car_rental_init');

function up_cpt_car_rental_init() {
  // Create new Car Rental custom post type
    $rental_labels = array(
                    'name'                 => _x('Car Rental', 'up-car-rental'),
                    'singular_name'        => _x('car rental', 'up-car-rental'),
                    'add_new'              => _x('Add Car Rental Item', 'up-car-rental'),
                    'add_new_item'         => __('Add New Car Rental Item', 'up-car-rental'),
                    'edit_item'            => __('Edit Car Rental Item', 'up-car-rental'),
                    'new_item'             => __('New Car Rental Item', 'up-car-rental'),
                    'view_item'            => __('View Car Rental Item', 'up-car-rental'),
                    'search_items'         => __('Search  Car Rental Items','up-car-rental'),
                    'not_found'            =>  __('No Car Rental Items found', 'up-car-rental'),
                    'not_found_in_trash'   => __('No Car Rental Items found in Trash', 'up-car-rental'),
                    'parent_item_colon'    => '',
                    'menu_name'          => _x( 'Car Rental', 'admin menu', 'up-car-rental' )
  );
  $carrental_args = array(
                    'labels'              => $rental_labels,
                    'public'              => true,
                    'publicly_queryable'  => true,
                    'exclude_from_search' => false,
                    'show_ui'             => true,
                    'show_in_menu'        => true, 
                    'query_var'           => true,
                    'rewrite'             => array( 
                    							'slug'       => WPCR_POST_TYPE,
                    							'with_front' => false
                							),
                    'capability_type'     => 'post',
                    'has_archive'         => true,
                    'hierarchical'        => false,
                    'menu_position'       => 5,
                	'menu_icon'   		  => 'dashicons-car',
                    'supports'            => array('title','editor','thumbnail'),
					'show_in_rest'		  => true,
                    'taxonomies'          => array('')
  );
    
	register_post_type( WPCR_POST_TYPE, apply_filters( 'up_store_registered_post_type_args', $carrental_args ) );
}

/* Register Taxonomy */
add_action( 'init', 'carrental_taxonomies');

function carrental_taxonomies() {
    $labels = array(
                'name'              => _x( 'Vehicle Type Category', 'up-car-rental' ),
                'singular_name'     => _x( 'Vehicle Type Category', 'up-car-rental' ),
                'search_items'      => __( 'Search Category', 'up-car-rental' ),
                'all_items'         => __( 'All Category', 'up-car-rental' ),
                'parent_item'       => __( 'Parent Category', 'up-car-rental' ),
                'parent_item_colon' => __( 'Parent Category:', 'up-car-rental' ),
                'edit_item'         => __( 'Edit Category', 'up-car-rental' ),
                'update_item'       => __( 'Update Category', 'up-car-rental' ),
                'add_new_item'      => __( 'Add New Category', 'up-car-rental' ),
                'new_item_name'     => __( 'New Category Name', 'up-car-rental' ),
                'menu_name'         => __( 'Vehicle Type Category', 'up-car-rental' ),
    );

    $args = array(
                'hierarchical'      => true,
                'labels'            => $labels,
                'show_ui'           => true,
                'show_admin_column' => true,
                'query_var'         => true,
                'rewrite'           => array( 'slug' => WPVT_CAT ),
    );
    register_taxonomy( WPVT_CAT, array( WPCR_POST_TYPE ), $args );
}

function car_rental_rewrite_flush() {
	up_cpt_car_rental_init();
    carrental_taxonomies();

    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'car_rental_rewrite_flush' );
