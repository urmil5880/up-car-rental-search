<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;	// Exit if accessed directly
}

function up_car_rental_add_meta_box() {
//this will add the metabox for the rental post type
$screens = array( WPCR_POST_TYPE );

foreach ( $screens as $screen ) {

    add_meta_box(
        'rental_sectionid',
        __( 'Car Details', 'rental_textdomain' ),
        'up_car_rental_meta_box_callback',
        $screen
    );
   }
}
add_action( 'add_meta_boxes', 'up_car_rental_add_meta_box' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function up_car_rental_meta_box_callback( $post ) {

// Add a nonce field so we can check for it later.
wp_nonce_field( 'up_car_rental_save_meta_box_data', 'up_car_rental_meta_box_nonce' );

/*
 * Use get_post_meta() to retrieve an existing value
 * from the database and use the value for the form.
 */
    $vehicle_number_value = get_post_meta( $post->ID, '_vehicle_number', true );

    echo '<label for="vehicle_number_field">';
    _e( 'Vehicle Number', 'rental_textdomain' );
    echo '</label> ';
    echo '<input type="text" id="vehicle_number_field" name="vehicle_number_field" value="' . esc_attr( $vehicle_number_value ) . '" size="100" /><br>';

    $driver_name_value = get_post_meta( $post->ID, '_driver_name', true );

    echo '<label for="driver_name_field">';
    _e( 'Driver name', 'rental_textdomain' );
    echo '</label> ';
    echo '<input type="text" id="driver_name_field" name="driver_name_field" value="' . esc_attr( $driver_name_value ) . '" size="100" /><br>';

}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
 function up_car_rental_save_meta_box_data( $post_id ) {

 if ( ! isset( $_POST['up_car_rental_meta_box_nonce'] ) ) {
    return;
 }

 if ( ! wp_verify_nonce( $_POST['up_car_rental_meta_box_nonce'], 'up_car_rental_save_meta_box_data' ) ) {
    return;
 }

 if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
    return;
 }

if ( ! isset( $_POST['vehicle_number_field'] ) ) {
    return;
}

$vehicle_number = sanitize_text_field( $_POST['vehicle_number_field'] );

update_post_meta( $post_id, '_vehicle_number', $vehicle_number );


if ( ! isset( $_POST['driver_name_field'] ) ) {
    return;
}
$driver_name = sanitize_text_field( $_POST['driver_name_field'] );

update_post_meta( $post_id, '_driver_name', $driver_name );


}
add_action( 'save_post', 'up_car_rental_save_meta_box_data' );

?>
