<?php
// job search get search here and data all
function up_get_search_vehicle_data(){

  global $post;
  $vehiclename = $_POST['vehiclename'];
  $cat_id = $_POST['cat_id'];
  $cat_all = $_POST['catIdAll'];
  $catAll = $_POST['catAll'];
  $vehiclenumber = $_POST['vehiclenumber'];
  $drivername = $_POST['drivername'];
  
  if(isset($catAll)){
    $searchargs = array(
      'post_type' => WPCR_POST_TYPE,
      'posts_per_page' => -1,
    );
  }
  //If select Particular Category
  if(isset($_POST['cat_id']) && $_POST['cat_id']>0){
    $searchargs['tax_query'] = array(
         'relation' => 'AND',
        array(
          'hide_empty' => 0,
          'taxonomy' => WPVT_CAT,
          'field'    => 'id',
          'terms'    => $cat_id,
        ),
      );
  }
  //If Vehicle Title or Name is not Null or Empty
 if(isset($_POST['vehiclename']) && $_POST['vehiclename']!=""){
    $searchargs = array(
      'post_type' => WPCR_POST_TYPE,
      's' => $vehiclename,
      'posts_per_page' => -1,
    );
  }  
  //If Vehicle Number is not Null or Empty
   if(isset($_POST['vehiclenumber']) && $_POST['vehiclenumber']!=''){
    //echo "Hi jack 4";
    $searchargs['meta_query'] = array(
          'relation' => 'AND',
          array(
            'key' => '_vehicle_number',
            'value' => $vehiclenumber,
            'compare' => 'LIKE'
          )
    );
  } 
  //If Driver Name is not Null or Empty
  if($_POST['drivername']!=''){
    $searchargs['meta_query'] = array(
          'relation' => 'AND',
          array(
            'key' => '_driver_name',
            'value' => $drivername,
            'compare' => 'LIKE'
          )
    );
  } 

  $search_query = new WP_Query( $searchargs );

  $totalvehicle = count( $search_query );
  
  if( $search_query->have_posts() ) :
    echo '<section class="container">
        <div class="row justify-content-center">
        <div class="col-lg-8">';
          while( $search_query->have_posts() ): $search_query->the_post();  
            $result = '<div class="media entry-listing">';
              if (has_post_thumbnail( $car_query->ID ) ):
                  $attachmentId = get_post_thumbnail_id(get_the_ID());
                  $thumbnail_url = wp_get_attachment_image_src($attachmentId, 'car-image', false );
                  $thumbnail_url = $thumbnail_url[0];
                $result .= '<div class="entry-thumb">';
                        $result .= '<img src="'.$thumbnail_url.'" class="img-thumbnail" alt="">';
                $result .= '</div>';
              endif;
              $result .= '<div class="media-body pl-4">';
                $result .= '<h3 class="border-bottom title pb-1">'.get_the_title().'</h3>';
                  $result .= '<div class="entry-info d-flex flex-column flex-md-row justify-content-between align-items-start align-items-lg-center">';
                    $driver_name = get_post_meta( get_the_ID(), '_driver_name', true );
                    $vehicle_number = get_post_meta( get_the_ID(), '_vehicle_number', true ); 
                    $result .= '<p>Vehical Number : '.$vehicle_number.'</p>';
                    $result .= '<p>Driver name: '.$driver_name.'</p>';
                  $result .= '</div>';
                    $result .= '<div class="entry-content">';
                    $result .= '<p>Vehicle type : ';
                      $rsterms = get_the_terms(get_the_ID(), WPVT_CAT);
                      $reseCats = '';
                        foreach ($rsterms as $rsterm) {
                           $reseCats .= ' <span class="cardSubtitle">' . esc_html($rsterm->name) . '</span>';
                        }
                        $reseCats = trim($reseCats); //remove extra space from end
                      $result .= rtrim($reseCats, ',');
                      $result .= '</p>';
                      $result .= '<p>Description: '.wp_trim_words( get_the_content(), 20, '...' ).'</p>';
                    $result .= '</div>';
                    $result .= '<a href="'.get_the_permalink().'" class="mt-5 btn btn-view">View Details</a>';
                 $result .= '</div>';
                $result .= '</div>';
             $result .= '<div class="seprater">';
                $result .= '<img src="'.SEPRATER_IMG.'" alt="">';
             $result .= '</div>';
          echo $result;

          endwhile;
          wp_reset_postdata();
  else:
    echo '<div class="media entry-listing">There are currently no vehicles should be searchable available.</div>';
  endif;
  echo '</div></div>
    </section>';

  die(); 
}
add_action('wp_ajax_nopriv_up_get_search_vehicle_data', 'up_get_search_vehicle_data');
add_action('wp_ajax_up_get_search_vehicle_data', 'up_get_search_vehicle_data');
