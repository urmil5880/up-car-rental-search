<?php

if ( !defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

function wpcr_search_filter_vehicle( $atts, $content = null ){
// setup the query
ob_start(); ?>    
  <section class="container">
    <div class="row mt-5 justify-content-center">
     <div class="col-lg-8">
        <form method="POST" id="vehicleForm" class="filter-form">
           <div class="form-row align-items-end mb-3">
              <div class="form-group col-md-4 mb-0">
                 <label for="inputEmail4">Vehical Title</label>
                 <input type="text" class="form-control" name="vehiclename" id="vehiclename"  />
              </div>
              <div class="form-group col-md-4 mb-0">
                 <label for="inputPassword4">Select Type</label>
                 <?php
                  $vehicle_category = get_terms(WPVT_CAT, array('hide_empty' => false, 'parent' => 0));
                  if (!empty($vehicle_category)) :
                    echo '<select class="form-control singleOption getcategorylist" name="categoryfilter" >
                    <option selected>Select Type</option>
                    <option data-get_cat="all_category" name="all" value="">All Vehicles</option>';

                    foreach ($vehicle_category as $term) :
                      echo '<option data-get_cat_value="' . $term->term_id . '" value="' . $term->term_id . '">' . $term->name . '</option>'; // ID of the category as the value of an option
                    endforeach;
                    echo '</select>';
                  endif; ?>
              </div>
           </div>
           <div class="form-row align-items-end mb-3">
              <div class="form-group col-md-4 mb-0">
                 <label for="inputEmail4">Vehical Number</label>
                  <input type="text" class="form-control" name="vehiclenumber" id="vehiclenumber" />
              </div>
              <div class="form-group col-md-4 mb-0">
                 <label for="inputEmail4">Driver Name</label>
                 <input type="text" class="form-control" name="drivername" id="drivername" />
              </div>
              <div class="form-group col-md-4 mb-0">
                  <button type="button" class="btn btn-filter btn-search-vehicle">Search</button>
              </div>
           </div>
        </form>
     </div>
    </div>
  </section>

  <div class="vehiclelistingWrap">
    <div class="container">
      <div class="row mt-5 justify-content-center">
          <div class="col-lg-12">
            <div class="vehicle_search_results">
                <section class="container">
                <div class="row justify-content-center">
                <?php
                $car_query = new WP_Query( array(
                    'post_type'     => WPCR_POST_TYPE,
                    'posts_per_page'  => -1,
                    'post_status'     =>  'publish',
                    'order'       => 'ASC',
                    'orderby'       => 'title',
                ) );
                if ( $car_query->have_posts() ) { ?>
                 <div class="col-lg-8">
                    <?php while ( $car_query->have_posts() ) : $car_query->the_post(); ?>
                        <div class="media entry-listing">
                          <?php if (has_post_thumbnail( $car_query->ID ) ): ?>
                          <?php 
                              $attachmentId = get_post_thumbnail_id(get_the_ID());
                              $thumbnail_url = wp_get_attachment_image_src($attachmentId, 'car-image', false );
                              $thumbnail_url = $thumbnail_url[0];
                              ?>
                              <div class="entry-thumb">
                                  <img src="<?php echo $thumbnail_url; ?>" class="img-thumbnail" alt="">
                              </div>
                          <?php endif; ?>
                          <div class="media-body pl-4">
                              <h3 class="border-bottom title pb-1"><?php the_title(); ?></h3>
                              <div class="entry-info d-flex flex-column flex-md-row justify-content-between align-items-start align-items-lg-center">
                                  <?php $driver_name = get_post_meta( get_the_ID(), '_driver_name', true );
                                  $vehicle_number = get_post_meta( get_the_ID(), '_vehicle_number', true ); ?>
                                 <p>Vehical Number : <?=$vehicle_number;?></p>
                                 <p>Driver name: <?=$driver_name;?></p>
                              </div>
                              <div class="entry-content">
                                 <p>Description: <?=wp_trim_words( get_the_content(), 20, '...' );?></p>
                              </div>
                              <a href="<?php the_permalink(); ?>" class="mt-5 btn btn-view">View Details</a>
                          </div>
                      </div>
                      <div class="seprater">
                         <img src="<?=SEPRATER_IMG;?>" alt="">
                      </div>
                    <?php endwhile;
                      wp_reset_postdata(); ?>
                  </div>
                <?php $myvariable = ob_get_clean();
                return $myvariable;
                }else{
                   echo '<div class="col-lg-8">';
                   echo '<p><strong>No Vehicle Found</strong></p>';
                   echo '</div>';
                }
                wp_reset_postdata(); 
                return ob_get_clean();?>
                  </div>
              </section>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php  
}

// '[up_search_vehicles]' shortcode
add_shortcode('up_search_vehicles','wpcr_search_filter_vehicle');

