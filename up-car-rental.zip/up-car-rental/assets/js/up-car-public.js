jQuery(document).ready(function($) {
  // vehicle search ajax call js
  $(document).on('click', '.btn-search-vehicle', function() {
      var formData = $("#vehicleForm").serialize();
      var ajaxurl = jmax.ajaxurl;
     
      var vehiclename = $('#vehiclename').val();
      var catID = $('.getcategorylist').find("option:selected").attr('data-get_cat_value');
      var catAll = $('.getcategorylist').find('option:selected').attr("name");
      var vehiclenumber = $('#vehiclenumber').val();
      var drivername = $('#drivername').val();
      
        $.ajax({
            type   : "POST",
            url    : ajaxurl,
            data   : {
                      data: formData,
                      action : "up_get_search_vehicle_data",
                      vehiclename: vehiclename,
                      cat_id: catID,
                      catAll: catAll,
                      vehiclenumber: vehiclenumber,
                      drivername: drivername

                    },
            success:function(data){
                $('.vehicle_search_results').html( data );   
                $('.vehicle_search_results').fadeIn();        
            },
            error: function (data) {
              $('.vehicle_search_results').fadeIn();  
            },
        });
        return false;
    }); 
});
