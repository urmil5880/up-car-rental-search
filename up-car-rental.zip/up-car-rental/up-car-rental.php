<?php
/*
Plugin Name: UP Car Rental
Plugin URL:  https://wordpress.org/
Text Domain: up-car-rental
Domain Path: /languages/
Description: A simple Car Rental plugin and custom post type with shortcode. vehicles listing for shortcode [up_all_vehicles] and search filter for short code [up_search_vehicles]
Version: 1.0.0
Author: Urmil Patel
Author URI: https://wordpress.org/
Contributors: Urmil Patel
*/

if( !defined( 'WPCR_VERSION' ) ) {
	define( 'WPCR_VERSION', '1.0.0' ); // Version of plugin
}
if( !defined( 'WPCR_DIR' ) ) {
	define( 'WPCR_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'WPCR_POST_TYPE' ) ) {
	define( 'WPCR_POST_TYPE', 'car-rental' ); // Plugin post type
}
if( !defined( 'WPVT_CAT' ) ) {
	define( 'WPVT_CAT', 'vehicle-type' ); // Plugin Category
}
if( !defined( 'SEPRATER_IMG' ) ) {
	define( 'SEPRATER_IMG', plugin_dir_url( __FILE__ ).'assets/images/seprater.png' ); // Plugin Category
}



register_activation_hook( __FILE__, 'install_car_rental_version' );
function install_car_rental_version() {
	if( is_plugin_active('up-car-rental/up-car-rental.php') ){
		 add_action('update_option_active_plugins', 'deactivate_car_rental_version');
	}
}

function deactivate_car_rental_version() {
   deactivate_plugins('up-car-rental/up-car-rental.php',true);
}

function up_car_rental_load_textdomain() {
	load_plugin_textdomain( 'up-car-rental', false, dirname( plugin_basename(__FILE__) ) . '/languages/' );
}
add_action('plugins_loaded', 'up_car_rental_load_textdomain');

function wp_car_rental_style_css_script() {
	wp_enqueue_style( 'cssstore',  plugin_dir_url( __FILE__ ). 'assets/css/stylecar.css', array(), WPCR_VERSION );
	wp_enqueue_style( 'bootstrap-css',  plugin_dir_url( __FILE__ ). 'assets/css/bootstrap.css', array(), WPCR_VERSION );
	wp_enqueue_script( 'up-car-public', plugin_dir_url( __FILE__ ) . 'assets/js/up-car-public.js', array( 'jquery' ), '', true);
  	$local_data['ajaxurl'] = admin_url( 'admin-ajax.php' );
  	wp_localize_script( 'up-car-public', 'jmax', $local_data );
}
add_action( 'wp_enqueue_scripts', 'wp_car_rental_style_css_script' );

function upcar_rental_display_tags( $query ) {
	if( is_tag() && $query->is_main_query() ) {       
	   $post_types = array( 'post', WPCR_POST_TYPE );
		$query->set( 'post_type', $post_types );
	}
}
add_filter( 'pre_get_posts', 'upcar_rental_display_tags' );

add_image_size( 'car-image', 160, 140, true);

// Posttype
require_once( WPCR_DIR . '/includes/up-car-rental-post-type.php' );

// Shortcode
require_once( WPCR_DIR . '/includes/up-car-rental-shortcode.php' );

// Custom Field
require_once( WPCR_DIR . '/includes/up-custom-field.php' );

// Search Filter Shortcode
require_once( WPCR_DIR . '/includes/up-car-rental-search-shortcode.php' );

// vehicles search file ajax call
require_once ( WPCR_DIR . '/includes/up-vehicles-search-list.php' );
